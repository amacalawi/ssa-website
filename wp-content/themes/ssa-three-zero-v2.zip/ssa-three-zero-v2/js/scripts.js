jQuery(document).ready(function ($) {
    jQuery('.bg, [data-bg]').each(function (i) {
        jQuery(this).css({'background-image': 'url('+jQuery(this).data('bg')+')'});
    });

    $('.owl-carousel').owlCarousel({
        autoHeight:true,
        animateOut: 'slideOutDown',
        animateIn: 'zoomIn',
        items:1,
        margin:30,
        stagePadding:30,
        smartSpeed:450
    });

})