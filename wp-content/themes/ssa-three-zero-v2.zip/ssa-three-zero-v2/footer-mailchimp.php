<!-- Begin MailChimp Signup Form -->
<form action="//ssagroup.us2.list-manage.com/subscribe/post?u=127beb85a5c7f8f3e42bef741&amp;id=4d7290eab2" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate newsletter-form" target="_blank" novalidate>
    <div id="mc_embed_signup_scroll" class="form-group">
        <div class="fg-line">
            <input type="email" value="" name="EMAIL" class="email form-control input-lg" id="mce-EMAIL" placeholder="ENTER YOUR EMAIL ADDRESS" required>
        </div>
    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
    <div class="form-control hidden" aria-hidden="true">
        <input type="text" name="b_127beb85a5c7f8f3e42bef741_4d7290eab2" tabindex="-1" value="">
    </div>
    <button type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="btn waves-effect">Subscribe Now!</button>
</form>
<!-- End mailChimp -->