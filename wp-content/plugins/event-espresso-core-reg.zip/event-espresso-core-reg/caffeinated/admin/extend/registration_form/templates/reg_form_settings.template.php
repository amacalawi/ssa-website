<div class="padding">
		<?php do_action( 'AHEE__Extend_Registration_Form_Admin_Page___reg_form_settings_template' ); ?>
</div>
