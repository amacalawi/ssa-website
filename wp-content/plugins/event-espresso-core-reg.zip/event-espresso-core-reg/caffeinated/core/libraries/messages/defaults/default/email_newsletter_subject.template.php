<?php printf( __('Message from %s', 'event_espresso'), EE_Registry::instance()->CFG->organization->get_pretty( 'name' ) ); ?>
