<div class="updated">
        <p><?php _e( "Mijireh is currently slurping your content. This will usually take a few minutes. Please login to Mijireh to see the slurp's progress", 'event_espresso' ); ?></p>
    </div>