<?php if (!defined('EVENT_ESPRESSO_VERSION'))
	exit('No direct script access allowed');
/**
 * mijireh_settings_after_form
 *
 * @package			Event Espresso
 * @subpackage
 * @author				Mike Nelson
 */
do_action('AHEE__EE_Mijireh__settings_end');
?><br/><?php
// End of file mijireh_settings_after_form.template.php