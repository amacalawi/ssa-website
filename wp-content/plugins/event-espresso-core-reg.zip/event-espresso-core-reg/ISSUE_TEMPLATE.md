
> Before submitting your issue, please ensure that what you are reporting is specific to Event Espresso 4.


When submitting an issue, please follow this rough guideline for your report.

### Is this a bug report?

* [ ] yes
* [ ] no

### What branch did this occur in?


### What version of WordPress is on the site this issue happened?


### Outline the steps to reproduce



### Please include any screenshots ar screencasts that can help illustrate the issue (if possible).



### Please include any links to the page(s) demonstrating this issue (if possible).


