<p><strong><?php _e('Event Title', 'event_espresso'); ?></strong></p>
<p>
<?php _e('This is the name (title) of your event. HTML tags are supported here.', 'event_espresso'); ?>
</p>
<p><strong><?php _e('Event Description', 'event_espresso'); ?></strong></p>
<p>
<?php _e('The rich text editor can be used to create a description for your event. Similar to WordPress pages and posts, you can upload images and customize your text by using the options on the toolbar.', 'event_espresso'); ?>
</p>