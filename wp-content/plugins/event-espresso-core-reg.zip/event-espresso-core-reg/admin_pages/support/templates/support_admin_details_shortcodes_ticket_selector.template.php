<div class="padding">
    <p>
<?php _e('Displays a ticket selector for an event on a WordPress page or post.', 'event_espresso'); ?>
    </p>
    <ul>
        <li>[ESPRESSO_TICKET_SELECTOR event_id=your_event_id]</li>
    </ul>
</div>