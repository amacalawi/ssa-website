<div class="padding">
    <p>
<?php _e('Displays a list of events from a specific category on a WordPress page or post.', 'event_espresso'); ?>
    </p>
    <ul>
        <li>[ESPRESSO_EVENTS category_slug=free-events]</li>
    </ul>
</div>