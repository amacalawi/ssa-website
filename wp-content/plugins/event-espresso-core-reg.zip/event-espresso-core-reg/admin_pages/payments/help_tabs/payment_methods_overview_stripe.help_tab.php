<p><strong><?php _e('Stripe', 'event_espresso'); ?></strong></p>
<p>
<?php _e('TO-DO (LOC)', 'event_espresso'); ?>
</p>
<p><strong><?php _e('Stripe Settings', 'event_espresso'); ?></strong></p>
<p>
<?php _e('TO-DO (LOC)', 'event_espresso'); ?>
</p>