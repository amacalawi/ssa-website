<p><strong><?php _e('Cybersource', 'event_espresso'); ?></strong></p>
<p>
<?php _e('TO-DO (LOC)', 'event_espresso'); ?>
</p>
<p><strong><?php _e('Cybersource Settings', 'event_espresso'); ?></strong></p>
<p>
<?php _e('TO-DO (LOC)', 'event_espresso'); ?>
</p>