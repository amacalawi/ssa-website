<div class="misc-pub-section ee-icon ee-icon-venue ee-icon-color-grey ee-icon-size-18">
	<?php _e('Capacity', 'event_espresso'); ?>: <input name="vnu_capacity" type="text" class="small-text" value="<?php echo $vnu_capacity; ?>" />
</div>
<div class="misc-pub-section">
	<span class="ee-icon ee-icon-external-link ee-icon-color-grey ee-icon-size-18"></span>
	<?php _e('Venue Website', 'event_espresso'); ?>: <input name="vnu_url" type="text" class="all-options" value="<?php echo $vnu_url; ?>" />
</div>
<div class="misc-pub-section">
	<span class="ee-dashicons dashicons-format-status ee-icon-color-grey ee-icon-size-18"></span>
	<?php _e('Venue Phone #', 'event_espresso'); ?>: <input name="vnu_phone" type="text" class="all-options" value="<?php echo $vnu_phone; ?>" />
</div>